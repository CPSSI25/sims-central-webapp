export default function CommunicationHub() {
  return (
    <div className="p-8">
      <h2 className="text-xl font-bold mb-4">Communication Hub</h2>
      <p>Group chats and messaging between users will be handled here.</p>
    </div>
  );
}