export default function StudentRegistration() {
  return (
    <div className="p-8">
      <h2 className="text-xl font-bold mb-4">Student Registration</h2>
      <p>Form to register students will go here.</p>
    </div>
  );
}