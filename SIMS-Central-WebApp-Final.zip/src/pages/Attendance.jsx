export default function Attendance() {
  return (
    <div className="p-8">
      <h2 className="text-xl font-bold mb-4">Attendance Tracking</h2>
      <p>Staff and Student attendance records will be managed here.</p>
    </div>
  );
}