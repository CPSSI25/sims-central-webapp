export default function StaffRegistration() {
  return (
    <div className="p-8">
      <h2 className="text-xl font-bold mb-4">Staff Registration</h2>
      <p>Form to register staff members will go here.</p>
    </div>
  );
}